Place "control_templates.xml" file into Koda folder in order to have your own control creating properties. Look included file for example. 
The simplest way to create template - copy needed properties from some saved form.
You also can change default control naming template. Use %INSTANCE% macro where instance number should be placed. 